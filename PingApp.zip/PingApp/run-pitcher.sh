#!/bin/bash

export JAVA_HOME=/Users/vv/jdk/jdk-15.0.1.jdk/Contents/Home
export PATH=$JAVA_HOME/bin:$PATH

# echo $JAVA_HOME

java -classpath PingApp.jar com.company.pingapp.PingApp -p -port 10001 -size 50 -mps 10 -hostname localhost


