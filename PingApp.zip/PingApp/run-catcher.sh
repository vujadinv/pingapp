#!/bin/bash

export JAVA_HOME=/Users/vv/jdk/jdk-15.0.1.jdk/Contents/Home
export PATH=$JAVA_HOME/bin:$PATH

# echo $JAVA_HOME

java -classpath PingApp.jar com.company.pingapp.PingApp -c -port 10001 -bind 127.0.0.1

